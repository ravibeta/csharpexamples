﻿using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Data.Entity;
using NerdMentor.Web.Models;

namespace NerdMentor.Web.Persistence
{
    public class NerdMentorDbContext : IdentityDbContext<ApplicationUser>
    {
        public virtual DbSet<Mentor> Mentors { get; set; }

        public virtual DbSet<Rsvp> Rsvp { get; set; }

        public NerdMentorDbContext()
        {
            Database.EnsureCreatedAsync().Wait();
        }
    }
}
