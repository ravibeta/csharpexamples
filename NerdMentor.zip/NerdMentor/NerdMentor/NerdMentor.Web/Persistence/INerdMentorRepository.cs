﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NerdMentor.Web.Models;

namespace NerdMentor.Web.Persistence
{
    public interface INerdMentorRepository
    {
        IQueryable<Mentor> Mentors { get; }

        IQueryable<Rsvp> Rsvp { get; }

        Task<Mentor> GetMentorAsync(int MentorId);
        
        Task<List<Mentor>> GetMentorsAsync(DateTime? startDate, DateTime? endDate, string userName, string searchQuery, string sort, bool descending, double? lat, double? lng, int? pageIndex, int? pageSize);

        Task<List<Mentor>> GetPopularMentorsAsync();

        Task<Mentor> CreateMentorAsync(Mentor item);

        Task<Mentor> UpdateMentorAsync(Mentor Mentor);

        Task DeleteMentorAsync(int MentorId);

        int GetMentorsCount();

        Task<Rsvp> CreateRsvpAsync(Mentor Mentor, string userName);

        Task DeleteRsvpAsync(Mentor Mentor, string userName);
    }
}
