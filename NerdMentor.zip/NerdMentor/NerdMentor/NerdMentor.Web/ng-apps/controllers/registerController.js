﻿(function () {
    'use strict';

    angular
        .module('nerdDinner')
        .controller('registerController', registerController);

    /* Register Controller  */
    registerController.$inject = ['$scope', '$location'];

    function registerController($scope, $location) {
    }
})();