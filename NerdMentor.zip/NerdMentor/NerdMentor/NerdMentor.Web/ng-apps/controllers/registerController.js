﻿(function () {
    'use strict';

    angular
        .module('nerdMentor')
        .controller('registerController', registerController);

    /* Register Controller  */
    registerController.$inject = ['$scope', '$location'];

    function registerController($scope, $location) {
    }
})();