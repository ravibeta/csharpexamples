﻿(function () {
    'use strict';

    angular
        .module('nerdMentor')
        .controller('homeController', homeController)
        .controller('listController', listController)
        .controller('myController', myController)
        .controller('detailController', detailController)
        .controller('addController', addController)
        .controller('editController', editController)
        .controller('deleteController', deleteController);

    /* Home Controller  */
    homeController.$inject = ['$scope', '$location', 'mentor', 'mapService'];

    function homeController($scope, $location, mentor, mapService) {
        $scope.mentors = mentor.popular.query();

        $scope.selectMentor = function (mentorId) {
            $location.path("/mentors/detail/" + mentorId).search({ nocache: new Date().getTime() });
        };

        $scope.loadMap = function () {
            mapService.loadMap($scope.mentors, 4);
        };

        $scope.showLocationPin = function (mentor) {
            mapService.showInfoBoxPin(mentor);
        };

        $scope.hideInfoBoxPin = function (mentor) {
            mapService.hideInfoBoxPin();
        };

        $scope.showLocation = function (searchText) {
            mapService.findAddress(searchText, false);
        }

        $scope.home = function () {
            $location.path('/');
        };
    }

    /* Mentors List Controller  */
    listController.$inject = ['$scope', '$location', 'mentor'];

    function listController($scope, $location, mentor) {
        mentor.count().then(function (result) {
            $scope.bigTotalItems = result.success;
        });

        $scope.maxSize = 3;
        $scope.bigCurrentPage = 1;
        $scope.itemPerPage = 12;

        $scope.mentors = mentor.all.query({ pageIndex: $scope.bigCurrentPage, pageSize: $scope.itemPerPage });

        $scope.selectMentor = function (mentorId) {
            $location.path('/mentors/detail/' + mentorId);
        };

        $scope.pageChanged = function () {
            $scope.mentors = mentor.all.query({ pageIndex: $scope.bigCurrentPage, pageSize: $scope.itemPerPage });
        };
    }

    /* Mentors My Controller  */
    myController.$inject = ['$scope', '$location', 'mentor', 'isUserAuthenticated'];

    function myController($scope, $location, mentor, isUserAuthenticated) {
        if (isUserAuthenticated.success == 'False') {
            $location.path('/account/login');
        }

        $scope.mentors = mentor.my.query();

        $scope.selectMentor = function (mentorId) {
            $location.path('/mentors/detail/' + mentorId);
        };
    }

    /* Mentors Detail Controller  */
    detailController.$inject = ['$scope', '$routeParams', '$location', 'mentor', 'mapService', 'isUserAuthenticated'];

    function detailController($scope, $routeParams, $location, mentor, mapService, isUserAuthenticated) {
        $scope.mentor = mentor.all.get({ id: $routeParams.id });

        if (isUserAuthenticated.success == 'False') {
            $scope.isUserAuthenticated = isUserAuthenticated.success;
        }

        mentor.isUserHost($routeParams.id).then(function (result) {
            $scope.isUserHost = result.success;
        });

        mentor.isUserRegistered($routeParams.id).then(function (result) {
            $scope.isUserRegistered = result.success;
        });

        $scope.editMentor = function (mentorId) {
            $location.path('/mentors/edit/' + mentorId);
        };

        $scope.deleteMentor = function (mentorId) {
            $location.path('/mentors/delete/' + mentorId);
        };

        $scope.loadMap = function () {
            mapService.loadMap($scope.mentor);
        }
    }

    /* Mentors Create Controller */
    addController.$inject = ['$http', '$scope', '$location', 'mentor', 'mapService', 'isUserAuthenticated'];

    function addController($http, $scope, $location, mentor, mapService, isUserAuthenticated) {
        $scope.mentor = {
            title: '',
            description: '',
            eventDate: '',
            address: '',
            contactPhone: ''
        };

        if (isUserAuthenticated.success == 'False') {
            $location.path('/account/login');
        }

        $scope.loadDefaultMap = function () {
            mapService.loadDefaultMap();
        }

        $scope.changeAddress = function (address) {
            mapService.findAddress(address, true);
        }

        $scope.add = function () {
            var result = mentor.addMentor($scope.mentor);
            result.then(function (result) {
                if (result.success) {
                    if (result.data.mentorId) {
                        $location.path('/mentors/detail/' + result.data.mentorId);
                        $scope.error = false;
                    } else {
                        $scope.error = true;
                    }
                } else {
                    $scope.error = true;
                    $scope.errorMessage = result.error;
                }
            });
        };

        $scope.cancel = function () {
            $location.path('/');
        }
    }
    /* Mentors Edit Controller  */
    editController.$inject = ['$scope', '$routeParams', '$location', 'mentor', 'mapService', 'isUserAuthenticated'];

    function editController($scope, $routeParams, $location, mentor, mapService, isUserAuthenticated) {
        if (isUserAuthenticated.success == 'False') {
            $location.path('/account/login');
        }

        $scope.mentor = mentor.all.get({ id: $routeParams.id });

        $scope.$watch(eventDate, function (newValue) {
            $scope.mentor.eventDate = newValue;
        });

        $scope.$watch('mentor.eventDate', function (newValue) {
            $scope.eventDate = new Date($scope.mentor.eventDate);
        });

        $scope.loadMap = function () {
            mapService.loadMap($scope.mentor);
        }

        $scope.changeAddress = function (address) {
            mapService.findAddress(address, true);
        }

        $scope.edit = function () {
            var result = mentor.editMentor($routeParams.id, $scope.mentor);
            result.then(function (result) {
                if (result.success) {
                    $location.path('/mentors/detail/' + $routeParams.id);
                } else {
                    $scope.error = true;
                    $scope.errorMessage = result.error;
                }
            });
        }

        $scope.cancel = function () {
            $location.path('/mentors/detail/' + $routeParams.id);
        }
    }

    /* Mentors Delete Controller */
    deleteController.$inject = ['$scope', '$routeParams', '$location', 'mentor', 'isUserAuthenticated'];

    function deleteController($scope, $routeParams, $location, mentor, isUserAuthenticated) {
        if (isUserAuthenticated.success == 'False') {
            $location.path('/account/login');
        }

        $scope.mentor = mentor.all.get({ id: $routeParams.id });

        $scope.delete = function () {
            var result = mentor.deleteMentor($routeParams.id);
            result.then(function (result) {
                if (result.success) {
                    $location.path('/mentors/my');
                }
            });
        };

        $scope.cancel = function () {
            $location.path('/mentors/detail/' + $routeParams.id);
        };
    }

})();