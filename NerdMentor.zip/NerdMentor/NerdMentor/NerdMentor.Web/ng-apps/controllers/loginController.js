﻿(function () {
    'use strict';

    angular
        .module('nerdMentor')
        .controller('loginController', loginController);

    /* Login Controller  */
    loginController.$inject = ['$scope', '$location'];

    function loginController($scope, $location) {
    }
})();