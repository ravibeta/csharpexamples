﻿(function () {
    'use strict';

    angular
        .module('nerdDinner')
        .controller('loginController', loginController);

    /* Login Controller  */
    loginController.$inject = ['$scope', '$location'];

    function loginController($scope, $location) {
    }
})();