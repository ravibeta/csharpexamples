﻿(function () {
    'use strict';

    config.$inject = ['$routeProvider', '$locationProvider'];

    angular.module('nerdMentor', [
        'ngRoute', 'ui.bootstrap', 'mentorsService'
    ]).config(config);

    function config($routeProvider, $locationProvider) {
        $routeProvider
            .when('/', {
                title: 'Nerd Mentor',
                templateUrl: '/views/home.html',
                controller: 'homeController'
            })
            .when('/mentors/all', {
                title: 'Nerd Mentor - All Mentors',
                templateUrl: '/views/list.html',
                controller: 'listController'
            })
            .when('/mentors/my', {
                title: 'Nerd Mentor - My Mentors',
                templateUrl: '/views/my.html',
                controller: 'myController',
                resolve: { isUserAuthenticated: 'authService' }
            })
            .when('/mentors/add', {
                title: 'Nerd Mentor - Host Mentor',
                templateUrl: '/views/add.html',
                controller: 'addController',
                resolve: { isUserAuthenticated: 'authService' }
            })
            .when('/mentors/detail/:id', {
                title: 'Nerd Mentor - Details',
                templateUrl: '/views/detail.html',
                controller: 'detailController',
                resolve: { isUserAuthenticated: 'authService' }
            })
            .when('/mentors/edit/:id', {
                title: 'Nerd Mentor - Edit Mentor',
                templateUrl: '/views/edit.html',
                controller: 'editController',
                resolve: { isUserAuthenticated: 'authService' }
            })
            .when('/mentors/delete/:id', {
                title: 'Nerd Mentor - Delete Mentor',
                templateUrl: '/views/delete.html',
                controller: 'deleteController',
                resolve: { isUserAuthenticated: 'authService' }
            })
            .when('/account/login', {
                title: 'Nerd Mentor - Log In',
                templateUrl: '/account/login',
                controller: 'loginController',
            })
            .when('/account/register', {
                title: 'Nerd Mentor - Register',
                templateUrl: '/account/register',
                controller: 'registerController'
            })
            .when('/about', {
                title: 'Nerd Mentor - About',
                templateUrl: '/views/about.html',
            })
            .otherwise({ redirectTo: '/' });

        $locationProvider.html5Mode({
            enabled: true,
            requireBase: false
        });
    }
})();