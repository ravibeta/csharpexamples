﻿(function () {
    'use strict';

    angular
        .module('mentorsService', ['ngResource'])
        .factory('mentor', mentor)

    mentor.$inject = ['$resource', '$http', '$q'];

    function mentor($resource, $http, $q) {
        return {
            all: $resource('/api/mentors/:id', { id: "@_id" }),

            popular: $resource('/api/mentors/popular'),

            my: $resource('/api/mentors/my'),

            count: function () {
                return mentorHelper($http, $q, '/api/mentors/count')
            },

            isUserHost: function (mentorId) {
                return mentorHelper($http, $q, '/api/mentors/isUserHost?id=' + mentorId)
            },

            isUserRegistered: function (mentorId) {
                return mentorHelper($http, $q, '/api/mentors/isUserRegistered?id=' + mentorId)
            },

            addMentor: function (mentor) {
                var deferredObject = $q.defer();
                $http.post(
                    '/api/mentors', mentor
                ).
                success(function (data) {
                    if (data) {
                        deferredObject.resolve({ success: true, data: data });
                    } else {
                        deferredObject.resolve({ success: false });
                    }
                }).
                error(function (err) {
                    deferredObject.resolve({ error: err });
                });

                return deferredObject.promise;
            },

            editMentor: function (mentorId, mentor) {
                var deferredObject = $q.defer();
                $http.put(
                    '/api/mentors/' + mentorId, mentor
                ).
                success(function (data) {
                    if (data) {
                        deferredObject.resolve({ success: true });
                    } else {
                        deferredObject.resolve({ success: false });
                    }
                }).
                error(function (err) {
                    deferredObject.resolve({ error: err });
                });

                return deferredObject.promise;
            },

            deleteMentor: function (mentorId) {
                var deferredObject = $q.defer();
                $http.delete(
                    '/api/mentors/' + mentorId
                ).
                success(function (data) {
                    deferredObject.resolve({ success: true });
                }).
                error(function () {
                    deferredObject.resolve({ success: false });
                });

                return deferredObject.promise;
            },
        };
    }

    function mentorHelper($http, $q, url) {
        var deferredObject = $q.defer();
        $http.get(url).
        success(function (data) {
            if (data) {
                deferredObject.resolve({ success: data });
            }
        }).
        error(function () {
            deferredObject.resolve({ success: false });
        });

        return deferredObject.promise;
    }
})();