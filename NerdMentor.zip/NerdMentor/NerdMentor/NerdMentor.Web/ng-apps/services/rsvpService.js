﻿(function () {
    'use strict';

    angular
        .module('nerdMentor')
        .service('rsvpService', rsvpService);

    rsvpService.$inject = ['$http', '$q'];

    function rsvpService($http, $q) {
        this.addRsvp = function (mentorId) {
            var deferredObject = $q.defer();
            $http.post(
                '/api/rsvp?mentorId=' + mentorId
            ).
            success(function (data) {
                if (data) {
                    deferredObject.resolve({ success: true });
                } else {
                    deferredObject.resolve({ success: false });
                }
            }).
            error(function (err) {
                deferredObject.resolve({ error: err });
            });

            return deferredObject.promise;
        };

        this.cancelRsvp = function (mentorId) {
            var deferredObject = $q.defer();
            $http.delete(
                '/api/rsvp?mentorId=' + mentorId
            ).
            success(function (data) {
                if (data) {
                    deferredObject.resolve({ success: true });
                } else {
                    deferredObject.resolve({ success: false });
                }
            }).
            error(function (err) {
                deferredObject.resolve({ error: err });
            });

            return deferredObject.promise;
        };
    }
})();