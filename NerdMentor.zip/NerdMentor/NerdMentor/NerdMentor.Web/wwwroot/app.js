!function() {
    "use strict";
    function config($routeProvider, $locationProvider) {
        $routeProvider.when("/", {
            title: "Nerd Mentor",
            templateUrl: "/views/home.html",
            controller: "homeController"
        }).when("/Mentors/all", {
            title: "Nerd Mentor - All Mentors",
            templateUrl: "/views/list.html",
            controller: "listController"
        }).when("/Mentors/my", {
            title: "Nerd Mentor - My Mentors",
            templateUrl: "/views/my.html",
            controller: "myController",
            resolve: {
                isUserAuthenticated: "authService"
            }
        }).when("/Mentors/add", {
            title: "Nerd Mentor - Host Mentor",
            templateUrl: "/views/add.html",
            controller: "addController",
            resolve: {
                isUserAuthenticated: "authService"
            }
        }).when("/Mentors/detail/:id", {
            title: "Nerd Mentor - Details",
            templateUrl: "/views/detail.html",
            controller: "detailController",
            resolve: {
                isUserAuthenticated: "authService"
            }
        }).when("/Mentors/edit/:id", {
            title: "Nerd Mentor - Edit Mentor",
            templateUrl: "/views/edit.html",
            controller: "editController",
            resolve: {
                isUserAuthenticated: "authService"
            }
        }).when("/Mentors/delete/:id", {
            title: "Nerd Mentor - Delete Mentor",
            templateUrl: "/views/delete.html",
            controller: "deleteController",
            resolve: {
                isUserAuthenticated: "authService"
            }
        }).when("/account/login", {
            title: "Nerd Mentor - Log In",
            templateUrl: "/account/login",
            controller: "loginController"
        }).when("/account/register", {
            title: "Nerd Mentor - Register",
            templateUrl: "/account/register",
            controller: "registerController"
        }).when("/about", {
            title: "Nerd Mentor - About",
            templateUrl: "/views/about.html"
        }).otherwise({
            redirectTo: "/"
        }), $locationProvider.html5Mode({
            enabled: !0,
            requireBase: !1
        });
    }
    config.$inject = [ "$routeProvider", "$locationProvider" ], angular.module("nerdMentor", [ "ngRoute", "ui.bootstrap", "MentorsService" ]).config(config);
}(), function() {
    "use strict";
    function homeController($scope, $location, Mentor, mapService) {
        $scope.Mentors = Mentor.popular.query(), $scope.selectMentor = function(MentorId) {
            $location.path("/Mentors/detail/" + MentorId).search({
                nocache: new Date().getTime()
            });
        }, $scope.loadMap = function() {
            mapService.loadMap($scope.Mentors, 4);
        }, $scope.showLocationPin = function(Mentor) {
            mapService.showInfoBoxPin(Mentor);
        }, $scope.hideInfoBoxPin = function(Mentor) {
            mapService.hideInfoBoxPin();
        }, $scope.showLocation = function(searchText) {
            mapService.findAddress(searchText, !1);
        }, $scope.home = function() {
            $location.path("/");
        };
    }
    function listController($scope, $location, Mentor) {
        Mentor.count().then(function(result) {
            $scope.bigTotalItems = result.success;
        }), $scope.maxSize = 3, $scope.bigCurrentPage = 1, $scope.itemPerPage = 12, $scope.Mentors = Mentor.all.query({
            pageIndex: $scope.bigCurrentPage,
            pageSize: $scope.itemPerPage
        }), $scope.selectMentor = function(MentorId) {
            $location.path("/Mentors/detail/" + MentorId);
        }, $scope.pageChanged = function() {
            $scope.Mentors = Mentor.all.query({
                pageIndex: $scope.bigCurrentPage,
                pageSize: $scope.itemPerPage
            });
        };
    }
    function myController($scope, $location, Mentor, isUserAuthenticated) {
        "False" == isUserAuthenticated.success && $location.path("/account/login"), $scope.Mentors = Mentor.my.query(), 
        $scope.selectMentor = function(MentorId) {
            $location.path("/Mentors/detail/" + MentorId);
        };
    }
    function detailController($scope, $routeParams, $location, Mentor, mapService, isUserAuthenticated) {
        $scope.Mentor = Mentor.all.get({
            id: $routeParams.id
        }), "False" == isUserAuthenticated.success && ($scope.isUserAuthenticated = isUserAuthenticated.success), 
        Mentor.isUserHost($routeParams.id).then(function(result) {
            $scope.isUserHost = result.success;
        }), Mentor.isUserRegistered($routeParams.id).then(function(result) {
            $scope.isUserRegistered = result.success;
        }), $scope.editMentor = function(MentorId) {
            $location.path("/Mentors/edit/" + MentorId);
        }, $scope.deleteMentor = function(MentorId) {
            $location.path("/Mentors/delete/" + MentorId);
        }, $scope.loadMap = function() {
            mapService.loadMap($scope.Mentor);
        };
    }
    function addController($http, $scope, $location, Mentor, mapService, isUserAuthenticated) {
        $scope.Mentor = {
            title: "",
            description: "",
            eventDate: "",
            address: "",
            contactPhone: ""
        }, "False" == isUserAuthenticated.success && $location.path("/account/login"), $scope.loadDefaultMap = function() {
            mapService.loadDefaultMap();
        }, $scope.changeAddress = function(address) {
            mapService.findAddress(address, !0);
        }, $scope.add = function() {
            var result = Mentor.addMentor($scope.Mentor);
            result.then(function(result) {
                result.success ? result.data.MentorId ? ($location.path("/Mentors/detail/" + result.data.MentorId), 
                $scope.error = !1) : $scope.error = !0 : ($scope.error = !0, $scope.errorMessage = result.error);
            });
        }, $scope.cancel = function() {
            $location.path("/");
        };
    }
    function editController($scope, $routeParams, $location, Mentor, mapService, isUserAuthenticated) {
        "False" == isUserAuthenticated.success && $location.path("/account/login"), $scope.Mentor = Mentor.all.get({
            id: $routeParams.id
        }), $scope.$watch(eventDate, function(newValue) {
            $scope.Mentor.eventDate = newValue;
        }), $scope.$watch("Mentor.eventDate", function(newValue) {
            $scope.eventDate = new Date($scope.Mentor.eventDate);
        }), $scope.loadMap = function() {
            mapService.loadMap($scope.Mentor);
        }, $scope.changeAddress = function(address) {
            mapService.findAddress(address, !0);
        }, $scope.edit = function() {
            var result = Mentor.editMentor($routeParams.id, $scope.Mentor);
            result.then(function(result) {
                result.success ? $location.path("/Mentors/detail/" + $routeParams.id) : ($scope.error = !0, 
                $scope.errorMessage = result.error);
            });
        }, $scope.cancel = function() {
            $location.path("/Mentors/detail/" + $routeParams.id);
        };
    }
    function deleteController($scope, $routeParams, $location, Mentor, isUserAuthenticated) {
        "False" == isUserAuthenticated.success && $location.path("/account/login"), $scope.Mentor = Mentor.all.get({
            id: $routeParams.id
        }), $scope["delete"] = function() {
            var result = Mentor.deleteMentor($routeParams.id);
            result.then(function(result) {
                result.success && $location.path("/Mentors/my");
            });
        }, $scope.cancel = function() {
            $location.path("/Mentors/detail/" + $routeParams.id);
        };
    }
    angular.module("nerdMentor").controller("homeController", homeController).controller("listController", listController).controller("myController", myController).controller("detailController", detailController).controller("addController", addController).controller("editController", editController).controller("deleteController", deleteController), 
    homeController.$inject = [ "$scope", "$location", "Mentor", "mapService" ], listController.$inject = [ "$scope", "$location", "Mentor" ], 
    myController.$inject = [ "$scope", "$location", "Mentor", "isUserAuthenticated" ], 
    detailController.$inject = [ "$scope", "$routeParams", "$location", "Mentor", "mapService", "isUserAuthenticated" ], 
    addController.$inject = [ "$http", "$scope", "$location", "Mentor", "mapService", "isUserAuthenticated" ], 
    editController.$inject = [ "$scope", "$routeParams", "$location", "Mentor", "mapService", "isUserAuthenticated" ], 
    deleteController.$inject = [ "$scope", "$routeParams", "$location", "Mentor", "isUserAuthenticated" ];
}(), function() {
    "use strict";
    function loginController($scope, $location) {}
    angular.module("nerdMentor").controller("loginController", loginController), loginController.$inject = [ "$scope", "$location" ];
}(), function() {
    "use strict";
    function registerController($scope, $location) {}
    angular.module("nerdMentor").controller("registerController", registerController), 
    registerController.$inject = [ "$scope", "$location" ];
}(), function() {
    "use strict";
    function rsvpController($scope, $routeParams, $location, rsvpService) {
        $scope.showMessage = !1, $scope.addRsvp = function(MentorId) {
            "False" == $scope.isUserAuthenticated && $location.path("/account/login");
            var result = rsvpService.addRsvp(MentorId);
            result.then(function(result) {
                result ? ($scope.message = "Thanks - we'll see you there!", $scope.showMessage = !0, 
                $scope.isUserRegistered = !0) : $scope.showMessage = !1;
            });
        }, $scope.cancelRsvp = function(MentorId) {
            "False" == $scope.isUserAuthenticated && $location.path("/account/login");
            var result = rsvpService.cancelRsvp(MentorId);
            result.then(function(result) {
                result ? ($scope.message = "Sorry you can't make it!", $scope.showMessage = !0, 
                $scope.isUserRegistered = !1) : $scope.showMessage = !1;
            });
        };
    }
    function rsvpSection() {
        return {
            restrict: "E",
            templateUrl: "/views/rsvp.html",
            controller: rsvpController
        };
    }
    angular.module("nerdMentor").directive("rsvpSection", rsvpSection), rsvpController.$inject = [ "$scope", "$routeParams", "$location", "rsvpService" ];
}(), function() {
    "use strict";
    function authService($http, $q) {
        var deferredObject = $q.defer();
        return $http.get("/account/isUserAuthenticated").success(function(data) {
            data && deferredObject.resolve({
                success: data
            });
        }).error(function() {
            deferredObject.resolve({
                success: !1
            });
        }), deferredObject.promise;
    }
    angular.module("nerdMentor").service("authService", authService), authService.$inject = [ "$http", "$q" ];
}(), function() {
    "use strict";
    function Mentor($resource, $http, $q) {
        return {
            all: $resource("/api/Mentors/:id", {
                id: "@_id"
            }),
            popular: $resource("/api/Mentors/popular"),
            my: $resource("/api/Mentors/my"),
            count: function() {
                return MentorHelper($http, $q, "/api/Mentors/count");
            },
            isUserHost: function(MentorId) {
                return MentorHelper($http, $q, "/api/Mentors/isUserHost?id=" + MentorId);
            },
            isUserRegistered: function(MentorId) {
                return MentorHelper($http, $q, "/api/Mentors/isUserRegistered?id=" + MentorId);
            },
            addMentor: function(Mentor) {
                var deferredObject = $q.defer();
                return $http.post("/api/Mentors", Mentor).success(function(data) {
                    data ? deferredObject.resolve({
                        success: !0,
                        data: data
                    }) : deferredObject.resolve({
                        success: !1
                    });
                }).error(function(err) {
                    deferredObject.resolve({
                        error: err
                    });
                }), deferredObject.promise;
            },
            editMentor: function(MentorId, Mentor) {
                var deferredObject = $q.defer();
                return $http.put("/api/Mentors/" + MentorId, Mentor).success(function(data) {
                    data ? deferredObject.resolve({
                        success: !0
                    }) : deferredObject.resolve({
                        success: !1
                    });
                }).error(function(err) {
                    deferredObject.resolve({
                        error: err
                    });
                }), deferredObject.promise;
            },
            deleteMentor: function(MentorId) {
                var deferredObject = $q.defer();
                return $http["delete"]("/api/Mentors/" + MentorId).success(function(data) {
                    deferredObject.resolve({
                        success: !0
                    });
                }).error(function() {
                    deferredObject.resolve({
                        success: !1
                    });
                }), deferredObject.promise;
            }
        };
    }
    function MentorHelper($http, $q, url) {
        var deferredObject = $q.defer();
        return $http.get(url).success(function(data) {
            data && deferredObject.resolve({
                success: data
            });
        }).error(function() {
            deferredObject.resolve({
                success: !1
            });
        }), deferredObject.promise;
    }
    angular.module("MentorsService", [ "ngResource" ]).factory("Mentor", Mentor), Mentor.$inject = [ "$resource", "$http", "$q" ];
}(), function() {
    "use strict";
    function mapService($http, $location, $q) {
        function zoomMapToLocation(latitude, longitude) {
            map.setView({
                center: new Microsoft.Maps.Location(latitude, longitude),
                zoom: 10
            });
        }
        function loadDetailsMap(Mentor) {
            map.entities.clear(), map = null, infobox = null, infoboxLayer = new Microsoft.Maps.EntityCollection(), 
            map = new Microsoft.Maps.Map(document.getElementById("MentorMap"), {
                credentials: bingMapsKey,
                mapTypeId: Microsoft.Maps.MapTypeId.road
            });
            var locs = [], location = new Microsoft.Maps.Location(Mentor.latitude, Mentor.longitude);
            locs.push(location);
            var pin = new Microsoft.Maps.Pushpin(location, {
                icon: "../../images/poi_usergenerated.gif",
                width: 50,
                height: 50
            });
            pin.Id = Mentor.MentorId, pin.Title = Mentor.title, pin.Date = Mentor.eventDate, 
            pin.Address = Mentor.address, pin.Description = Mentor.description, pinLayer.push(pin), 
            Microsoft.Maps.Events.addHandler(pin, "mouseover", pinMouseOver), Microsoft.Maps.Events.addHandler(pin, "mouseout", pinMouseOut), 
            map.entities.push(pinLayer), map.entities.push(infoboxLayer);
            var bestview = Microsoft.Maps.LocationRect.fromLocations(locs);
            map.setView({
                bounds: bestview
            }), map.setView({
                zoom: 10
            });
        }
        function hideInfobox() {
            null != infobox && infobox.setOptions({
                visible: !1
            });
        }
        function pinInfoboxMouseLeave(e) {
            hideInfobox();
        }
        function startInfoboxTimer() {
            null != infobox && null != infobox.pinTimer && clearTimeout(infobox.pinTimer), null != infobox && (infobox.pinTimer = setTimeout(timerTriggered, 300));
        }
        function stopInfoboxTimer() {
            null != infobox && null != infobox.pinTimer && clearTimeout(infobox.pinTimer);
        }
        function pinInfoboxMouseEnter(e) {
            stopInfoboxTimer();
        }
        function pinMouseOver(e) {
            displayInfobox(e);
        }
        function pinMouseOut() {
            startInfoboxTimer();
        }
        function timerTriggered() {
            hideInfobox();
        }
        function displayInfobox(e) {
            hideInfobox(), stopInfoboxTimer();
            var pin = e.target;
            if (null != pin) {
                var currentMentorTitle = (pin.Id, pin.Title), date = new Date(pin.Date), dateString = date.toDateString(), location = pin.getLocation(), options = {
                    id: pin.Id,
                    zIndex: 999,
                    visible: !0,
                    showPointer: !0,
                    showCloseButton: !0,
                    title: currentMentorTitle,
                    description: popupDescription(pin.Description, dateString, pin.rsvps),
                    titleClickHandler: showDetail,
                    offset: new Microsoft.Maps.Point(-12, 40)
                };
                null != infobox && (map.entities.remove(infobox), map.entities.remove(infoboxLayer), 
                Microsoft.Maps.Events.hasHandler(infobox, "mouseleave") && Microsoft.Maps.Events.removeHandler(infobox.mouseLeaveHandler), 
                Microsoft.Maps.Events.hasHandler(infobox, "mouseenter") && Microsoft.Maps.Events.removeHandler(infobox.mouseEnterHandler), 
                infobox = null), infobox = new Microsoft.Maps.Infobox(location, options), infobox.mouseLeaveHandler = Microsoft.Maps.Events.addHandler(infobox, "mouseleave", pinInfoboxMouseLeave), 
                infobox.mouseEnterHandler = Microsoft.Maps.Events.addHandler(infobox, "mouseenter", pinInfoboxMouseEnter), 
                infoboxLayer.push(infobox), map.entities.push(infoboxLayer);
            }
        }
        function popupDescription(description, dateString, rsvps) {
            var mapDescription = "<strong>" + dateString + "</strong><p>" + description + "</p>";
            return rsvps && (mapDescription += "<p>" + rsvps + " RSVPs</p>"), mapDescription;
        }
        function showDetail() {
            window.location("/#Mentors/detail/8");
        }
        function loadMentorsOnMap(Mentors, zoomlevel) {
            for (var locs = [], i = 0; i < Mentors.length; i++) {
                var location = new Microsoft.Maps.Location(Mentors[i].latitude, Mentors[i].longitude);
                locs.push(location);
                var pin = new Microsoft.Maps.Pushpin(location, {
                    icon: "images/poi_usergenerated.gif",
                    width: 50,
                    height: 50
                });
                pin.Id = Mentors[i].MentorId, pin.Title = Mentors[i].title, pin.Date = Mentors[i].eventDate, 
                pin.Address = Mentors[i].address, pin.Description = Mentors[i].description, pin.rsvps = Mentors[i].rsvps.length, 
                pinLayer.push(pin), Microsoft.Maps.Events.addHandler(pin, "mouseover", pinMouseOver), 
                Microsoft.Maps.Events.addHandler(pin, "mouseout", pinMouseOut);
            }
            map.entities.push(pinLayer), map.entities.push(infoboxLayer);
            var bestview = Microsoft.Maps.LocationRect.fromLocations(locs);
            map.setView({
                bounds: bestview
            });
        }
        var map = null, infobox = null, infoboxLayer = new Microsoft.Maps.EntityCollection(), pinLayer = new Microsoft.Maps.EntityCollection(), bingMapsKey = "Al1IumsJbHmAUYWKYXq33XIxwbJCkRTRZcVGCO3wJD2J3-ICC0lWUp2Adu_z_qtt";
        this.loadDefaultMap = function() {
            map = new Microsoft.Maps.Map(document.getElementById("MentorMap"), {
                credentials: bingMapsKey,
                mapTypeId: Microsoft.Maps.MapTypeId.road,
                disableBirdseye: !0,
                showMapTypeSelector: !1
            }), map.setView({
                zoom: 1
            });
        }, this.findAddress = function(address, setPin) {
            var url = "http://dev.virtualearth.net/REST/v1/Locations?query=" + encodeURI(address) + "&jsonp=JSON_CALLBACK&key=" + bingMapsKey;
            $http.jsonp(url).success(function(result) {
                if (result && result.resourceSets && result.resourceSets.length > 0 && result.resourceSets[0].resources && result.resourceSets[0].resources.length > 0) if (setPin) {
                    var bbox = result.resourceSets[0].resources[0].bbox, location = (Microsoft.Maps.LocationRect.fromLocations(new Microsoft.Maps.Location(bbox[0], bbox[1]), new Microsoft.Maps.Location(bbox[2], bbox[3])), 
                    new Microsoft.Maps.Location(result.resourceSets[0].resources[0].point.coordinates[0], result.resourceSets[0].resources[0].point.coordinates[1])), pin = new Microsoft.Maps.Pushpin(location);
                    map.entities.clear(), map.entities.push(pin);
                    var bestview = Microsoft.Maps.LocationRect.fromLocations(location);
                    map.setView({
                        bounds: bestview
                    }), map.setView({
                        zoom: 10
                    });
                } else {
                    var bbox = result.resourceSets[0].resources[0].bbox;
                    zoomMapToLocation(bbox[0], bbox[1]);
                }
            }).error(function(data, status, error, thing) {
                console.log(data);
            });
        }, this.loadMap = function(Mentors, zoomlevel) {
            null != map && map.entities && (infobox = null, infoboxLayer = new Microsoft.Maps.EntityCollection()), 
            map = new Microsoft.Maps.Map(document.getElementById("MentorMap"), {
                credentials: bingMapsKey,
                mapTypeId: Microsoft.Maps.MapTypeId.road,
                disableBirdseye: !0,
                showMapTypeSelector: !1
            }), Mentors.$promise.then(function(result) {
                Mentors = result, Mentors.length ? loadMentorsOnMap(Mentors, zoomlevel) : loadDetailsMap(Mentors);
            });
        }, this.showInfoBoxPin = function(Mentor) {
            var location = new Microsoft.Maps.Location(Mentor.latitude, Mentor.longitude), pin = new Microsoft.Maps.Pushpin(location);
            pin.Id = Mentor.MentorId, pin.Title = Mentor.title, pin.Date = Mentor.eventDate, 
            pin.Description = Mentor.description, pin.Address = Mentor.address, pin.rsvps = Mentor.rsvps.length;
            var e = new Object();
            e.target = pin, displayInfobox(e);
        }, this.hideInfoBoxPin = function() {
            startInfoboxTimer();
        };
    }
    angular.module("nerdMentor").service("mapService", mapService), mapService.$inject = [ "$http", "$location", "$q" ];
}(), function() {
    "use strict";
    function rsvpService($http, $q) {
        this.addRsvp = function(MentorId) {
            var deferredObject = $q.defer();
            return $http.post("/api/rsvp?MentorId=" + MentorId).success(function(data) {
                data ? deferredObject.resolve({
                    success: !0
                }) : deferredObject.resolve({
                    success: !1
                });
            }).error(function(err) {
                deferredObject.resolve({
                    error: err
                });
            }), deferredObject.promise;
        }, this.cancelRsvp = function(MentorId) {
            var deferredObject = $q.defer();
            return $http["delete"]("/api/rsvp?MentorId=" + MentorId).success(function(data) {
                data ? deferredObject.resolve({
                    success: !0
                }) : deferredObject.resolve({
                    success: !1
                });
            }).error(function(err) {
                deferredObject.resolve({
                    error: err
                });
            }), deferredObject.promise;
        };
    }
    angular.module("nerdMentor").service("rsvpService", rsvpService), rsvpService.$inject = [ "$http", "$q" ];
}();