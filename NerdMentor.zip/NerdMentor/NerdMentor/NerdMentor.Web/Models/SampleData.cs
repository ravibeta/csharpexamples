﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.Framework.DependencyInjection;
using NerdMentor.Web.Persistence;

namespace NerdMentor.Web.Models
{
    public static class SampleData
    {
        public static async Task InitializeNerdMentor(IServiceProvider provider)
        {
            NerdMentorDbContext dbContext = provider.GetService<NerdMentorDbContext>();
            UserManager<ApplicationUser> userManager = provider.GetService<UserManager<ApplicationUser>>();

            INerdMentorRepository repository = new NerdMentorRepository(dbContext);

            var users = GetUsers();
            var mentors = GetMentors();

            foreach(RegisterViewModel user in users)
            {
                var applicationUser = new ApplicationUser
                {
                    UserName = user.Email
                };

                await userManager.CreateAsync(applicationUser, user.Password);
            }

            foreach (Mentor mentor in mentors)
            {
                await repository.CreateMentorAsync(mentor);
            }
        }

        private static RegisterViewModel[] GetUsers()
        {
            var users = new RegisterViewModel[]
                {
                    new RegisterViewModel { Email = "user1@xxx.com", Password = "!QAZ2wsx", ConfirmPassword = "!QAZ2wsx" },
                    new RegisterViewModel { Email = "user2@xxx.com", Password = "!QAZ2wsx", ConfirmPassword = "!QAZ2wsx" },
                    new RegisterViewModel { Email = "user3@xxx.com", Password = "!QAZ2wsx", ConfirmPassword = "!QAZ2wsx" },
                };

            return users;
        }

        private static Mentor[] GetMentors()
        {
            var mentors = new Mentor[]
                {
                new Mentor { Title = "Test Mentor One", Address = "Seattle, WA", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor One", EventDate = DateTime.Now, UserName = "user1@xxx.com", Latitude = 47.671798706054688, Longitude = -122.12323760986328 },
                new Mentor { Title = "Test Mentor Two", Address = "Redmond, WA", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Two", EventDate = DateTime.Now.AddDays(1), UserName = "user2@xxx.com", Latitude = 47.671798706054688, Longitude = -122.12323760986328 },
                new Mentor { Title = "Test Mentor Three", Address = "New York", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Three", EventDate = DateTime.Now.AddDays(2), UserName = "user3@xxx.com", Latitude = 40.712784, Longitude = 74.005941 },
                new Mentor { Title = "Test Mentor Four", Address = "Chicago", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Four", EventDate = DateTime.Now.AddDays(3), UserName = "user1@xxx.com", Latitude = 41.878114, Longitude = -87.629798 },
                new Mentor { Title = "Test Mentor Five", Address = "San Francisco", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Five", EventDate = DateTime.Now.AddDays(4), UserName = "user2@xxx.com", Latitude = 33.748995, Longitude = -84.387982 },
                new Mentor { Title = "Test Mentor Six", Address = "Atlanta", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Six", EventDate = DateTime.Now.AddDays(5), UserName = "user3@xxx.com", Latitude = 39.739236, Longitude = -104.990251 },
                new Mentor { Title = "Test Mentor Seven", Address = "Denver", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Seven", EventDate = DateTime.Now.AddDays(6), UserName = "user1@xxx.com", Latitude = 39.952584, Longitude = -75.165222 },
                new Mentor { Title = "Test Mentor Eight", Address = "Pittsburgh", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Eight", EventDate = DateTime.Now.AddDays(7), UserName = "user2@xxx.com", Latitude = 37.774929, Longitude = -122.4194160 },
                new Mentor { Title = "Test Mentor Nine", Address = "Kirkland, WA", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Nine", EventDate = DateTime.Now.AddDays(8), UserName = "user3@xxx.com", Latitude = 31.968599, Longitude = -99.901813 },
                new Mentor { Title = "Test Mentor Ten", Address = "Bellevue, WA", ContactPhone = "425-XXX-XXXX", Country = "USA", Description = "Test Mentor Ten", EventDate = DateTime.Now.AddDays(9), UserName = "user1@xxx.com", Latitude = 33.748995, Longitude = 74.005941 },
                };

            return mentors;
        }
    }
}