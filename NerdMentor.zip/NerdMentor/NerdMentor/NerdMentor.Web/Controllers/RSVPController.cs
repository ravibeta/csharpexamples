﻿using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Mvc;
using NerdMentor.Web.Models;
using NerdMentor.Web.Persistence;

namespace NerdMentor.Web.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class RsvpController : Controller
    {
        private readonly INerdMentorRepository _repository;

        private readonly UserManager<ApplicationUser> _userManager;

        public RsvpController(INerdMentorRepository repository, UserManager<ApplicationUser> userManager)
        {
            _repository = repository;
            _userManager = userManager;
        }

        [HttpPost]
        public async Task<IActionResult> CreateRsvpAsync(int mentorId)
        {
            var mentor = await _repository.GetMentorAsync(mentorId);
            if (mentor == null)
            {
                return HttpNotFound();
            }

            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());
            var rsvp = await _repository.CreateRsvpAsync(mentor, user.UserName);
            return new JsonResult(rsvp);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteRsvpAsync(int mentorId)
        {
            var mentor = await _repository.GetMentorAsync(mentorId);
            if (mentor == null)
            {
                return HttpNotFound();
            }

            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());

            await _repository.DeleteRsvpAsync(mentor, user.UserName);
            return new HttpStatusCodeResult((int)HttpStatusCode.NoContent);
        }
    }
}