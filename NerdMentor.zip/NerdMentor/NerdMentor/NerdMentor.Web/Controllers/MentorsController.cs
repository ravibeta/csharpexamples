﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Authorization;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Mvc;
using NerdMentor.Web.Models;
using NerdMentor.Web.Persistence;
using NerdMentor.Web.Common;

namespace NerdMentor.Web.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    public class MentorsController : Controller
    {
        private readonly INerdMentorRepository _repository;

        private readonly UserManager<ApplicationUser> _userManager;

        public MentorsController(INerdMentorRepository repository, UserManager<ApplicationUser> userManager)
        {
            _repository = repository;
            _userManager = userManager;
        }

        [HttpGet("{id:int}", Name = "GetMentorById")]
        [AllowAnonymous]
        public async Task<IActionResult> GetMentorAsync(int id)
        {
            var mentor = await _repository.GetMentorAsync(id);
            if (mentor == null)
            {
                return HttpNotFound();
            }

            return new ObjectResult(mentor);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IEnumerable<Mentor>> GetMentorsAsync(
            DateTime? startDate,
            DateTime? endDate,
            double? lat,
            double? lng,
            int? pageIndex,
            int? pageSize,
            string searchQuery = null,
            string sort = null,
            bool descending = false)
        {
            return await _repository.GetMentorsAsync(startDate, endDate, string.Empty, searchQuery, sort, descending, lat, lng, pageIndex, pageSize);
        }

        [HttpGet("my")]
        [AllowAnonymous]
        public async Task<IEnumerable<Mentor>> GetMyMentorsAsync(
            DateTime? startDate,
            DateTime? endDate,
            double? lat,
            double? lng,
            int? pageIndex,
            int? pageSize,
            string searchQuery = null,
            string sort = null,
            bool descending = false)
        {
            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());
            return await _repository.GetMentorsAsync(startDate, endDate, user.UserName, searchQuery, sort, descending, lat, lng, pageIndex, pageSize);
        }

        [HttpGet("popular")]
        [AllowAnonymous]
        public async Task<IEnumerable<Mentor>> GetPopularMentorsAsync()
        {
            return await _repository.GetPopularMentorsAsync();
        }

        [HttpGet("count")]
        [AllowAnonymous]
        public int GetMentorsCount()
        {
            return _repository.GetMentorsCount();
        }

        [HttpGet("isUserHost")]
        [AllowAnonymous]
        public async Task<IActionResult> IsUserHost(int id)
        {
            if (Context.User.GetUserId() == null)
            {
                return new ObjectResult(false);
            }

            var mentor = await _repository.GetMentorAsync(id);
            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());
            return new ObjectResult(mentor.IsUserHost(user.UserName));
        }

        [HttpGet("isUserRegistered")]
        [AllowAnonymous]
        public async Task<IActionResult> IsUserRegistered(int id)
        {
            if (Context.User.GetUserId() == null)
            {
                return new ObjectResult(false);
            }

            var mentor = await _repository.GetMentorAsync(id);
            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());
            return new ObjectResult(mentor.IsUserRegistered(user.UserName));
        }

        [HttpPost]
        public async Task<IActionResult> CreateMentorAsync([FromBody] Mentor mentor)
        {
            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());
            mentor.UserName = user.UserName;

            GeoLocation.SearchByPlaceNameOrZip(mentor);
            mentor = await _repository.CreateMentorAsync(mentor);
            var url = Url.RouteUrl("GetMentorById", new { id = mentor.MentorId }, Request.Scheme, Request.Host.ToUriComponent());

            Context.Response.StatusCode = (int)HttpStatusCode.Created;
            Context.Response.Headers["Location"] = url;
            return new ObjectResult(mentor);
        }

        [HttpPut("{id:int}", Name = "UpdateMentorById")]
        public async Task<IActionResult> UpdateMentorAsync(int id, [FromBody] Mentor mentor)
        {
            if (mentor.MentorId != id)
            {
                return new HttpStatusCodeResult((int)HttpStatusCode.BadRequest);
            }

            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());
            if (!mentor.IsUserHost(user.UserName))
            {
                return HttpNotFound();
            }

            GeoLocation.SearchByPlaceNameOrZip(mentor);
            mentor = await _repository.UpdateMentorAsync(mentor);
            return new ObjectResult(mentor);
        }

        [HttpDelete("{id:int}", Name = "DeleteMentorById")]
        public async Task<IActionResult> DeleteMentorAsync(int id)
        {
            var mentor = await _repository.GetMentorAsync(id);
            var user = await _userManager.FindByIdAsync(Context.User.GetUserId());

            if (!mentor.IsUserHost(user.UserName))
            {
                return HttpNotFound();
            }

            await _repository.DeleteMentorAsync(id);
            return new HttpStatusCodeResult((int)HttpStatusCode.NoContent);
        }
    }
}
