﻿using System;
using FileOwner.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using System.Web;
using System.Web.Script;
using System.Web.Script.Serialization;

namespace FileOwner.Tests.Controllers
{
    [TestClass]
    public class DesiredControllerTest
    {
        [TestMethod]
        public void AutoCompleteTest()
        {
            // Arrange
            DesiredController controller = new DesiredController();

            // Act
            JsonResult result = controller.Autocomplete("Headphones", "Wireless") as JsonResult;

            // Assert           
            dynamic dobj = result.Data;
            Assert.AreEqual(dobj != null, true);
            Assert.AreEqual(dobj.suggestions != null, true);
            Assert.AreEqual(dobj.suggestions.Length > 0, true);
            Assert.AreEqual(dobj.suggestions[0].id != "", true);
            Assert.AreEqual(dobj.suggestions[0].name != "", true);

        }

        [TestMethod]
        public void SearchByJson()
        {
            // Arrange
            DesiredController controller = new DesiredController();

            // Act
            JsonResult result = controller.Search(controller.SampleSearchRequest()) as JsonResult;

            // Assert
            dynamic dobj = result.Data;
            Assert.AreEqual(dobj != null, true);
            Assert.AreEqual(dobj.pagination != null, true);
            Assert.AreEqual(dobj.pagination.from != 0, true);
            Assert.AreEqual(dobj.pagination.size != 0, true);
            Assert.AreEqual(dobj.products != null, true);
            Assert.AreEqual(dobj.products.Length > 0, true);
            Assert.AreEqual(dobj.products[0].title != "", true);
            Assert.AreEqual(dobj.products[0].productId != "", true);
            Assert.AreEqual(dobj.products[0].brandName != "", true);
            Assert.AreEqual(dobj.products[0].categoryId != "", true);
            Assert.AreEqual(dobj.products[0].categoryName != "", true);
        }
    }
}
