The program.cs is a standalone source code that captures the essence of the project. 
The webAPI methods are in the controller file.